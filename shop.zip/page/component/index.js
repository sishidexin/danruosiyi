//获取应用实例
import {
  getSellers
} from '../utils/apis'

Page({
  data: {
    imgUrls: [
      '/image/b1.png',
      '/image/b2.png',
      '/image/b3.png'
    ],
    // 分类数据
    category: [
      {
        "category_id": "1",
        "title": "清洁产品",
        "icon": "/image/category/1.png"
      },
      {
        "category_id": "2",
        "title": "补水喷雾",
        "icon": "/image/category/2.png"
      },
      {
        "category_id": "3",
        "title": "护肤乳液",
        "icon": "/image/category/3.png"
      },
      {
        "category_id": "4",
        "title": "锁水面霜",
        "icon": "/image/category/4.png"
      },
      {
        "category_id": "5",
        "title": "香水香氛",
        "icon": "/image/category/5.png"
      },
      {
        "category_id": "6",
        "title": "彩妆产品",
        "icon": "/image/category/6.png"
      },
      {
        "category_id": "7",
        "title": "底妆修容",
        "icon": "/image/category/7.png"
      },
      {
        "category_id": "8",
        "title": "美妆工具",
        "icon": "/image/category/8.png"
      }
    ],
    // 商店数据
    business: [
      { 
        "id":'bk',
        "title": "雅诗兰黛旗舰店",
        "sellcount": 360060,
        "startsell": 1000+ "-" +80,
        "packagesell": 999+"+",
        "shopimg": "../../image/ysld.jpg",
        "pmin": 30,
        "dist": 450,
        "shopicon": [
          "../../image/icon/准.png",
          "../../image/icon/减.png",
          "../../image/icon/折.png",
          "../../image/icon/特.png",
        ]
      },
      {
        "id": 'ycyk',
        "title": "MAC旗舰店",
        "sellcount": 324700,
        "startsell": 1000+ "-" +60,
        "packagesell": 999+"+",
        "shopimg": "../../image/ye.png",
        "pmin": 23,
        "dist": 550,
        "shopicon": [
          "../../image/icon/折.png",
          "../../image/icon/特.png",
        ]
      },
      {
        "id":'hdl',
        "title": "YSL旗舰店",
        "sellcount": 12360,
        "startsell": 1000+ "-" +40,
        "packagesell": 999+"+",
        "shopimg": "../../image/hdl.png",
        "pmin": 36,
        "dist": 480,
        "shopicon": [
          "../../image/icon/减.png",
          "../../image/icon/折.png",
        ]
      },
      {
        "id": 'dj',
        "title": "兰蔻旗舰店",
        "sellcount": 13720,
        "startsell": 900+ "-" +70,
        "packagesell": 999+"+",
        "shopimg": "../../image/dj.jpg",
        "pmin": 23,
        "dist": 20,
        "shopicon": [
          "../../image/icon/折.png",
          "../../image/icon/特.png",
          "../../image/icon/减.png",
          
        ]
      },
      {
        "id": 'xyx',
        "title": "香奈儿旗舰店",
        "sellcount": 1720,
        "startsell": 800+ "-" +60,
        "packagesell": 999+"+",
        "shopimg": "../../image/xyx.jpg",
        "pmin": 20,
        "dist": 220,
        "shopicon": [
          "../../image/icon/折.png",
          "../../image/icon/减.png",

        ]
      },
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 3000,
    duration: 800,
  },
  redTo: function(e) {
    let shopid = e.currentTarget.dataset.shop
    console.log(shopid)
    wx.navigateTo({
      url: 'category/category?d='+shopid
    })
  }
})