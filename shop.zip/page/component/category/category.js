Page({
    data: {
        
        detail:[],
        curIndex: 0,
        isScroll: false,
        toView: 'guowei'
    },
    onLoad: function (options) {
      // 判断进入路由参数，进行相应路由渲染
      if (options.d === 'bk') {
        console.log('')
        this.setData({
          category: [
            { name: '修护臻选', id: 'hanbao' },
            { name: '冻龄白金', id: 'taocan' },
            { name: '肌肤需求', id: 'zaocan' },
            { name: '彩妆分类', id: 'xiaoshi' },
            { name: '专研系列', id: 'tiandian' },
            { name: '护肤分类', id: 'yinliao' }
          ],
          detail: [
            {
              id: "hanbao",
              banner: '../../../image/bk/banner.jpg',
              cate: '修护臻选',
              detail: [
                {
                  id: 'bk1',
                  thumb: "../../../image/bk/c1.png",
                  name: "小棕瓶眼霜",
                  price: 500,
                  stock: '有货',
                  detail: '这里是小棕瓶眼霜详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },
                // {
                //   id: 'bk2',
                //   thumb: "../../../image/bk/c2.png",
                //   name: "德州熏厚牛堡",
                //   price: 25,
                //   stock: '有货',
                //   detail: '这里是德州熏厚牛堡详情。',
                //   parameter: 'test',
                //   service: '不支持退货'
                // },
                // {
                //   id: 'bk3',
                //   thumb: "../../../image/bk/c3.png",
                //   name: "王堡",
                //   price: 25,
                //   stock: '有货',
                //   detail: '这里是王堡详情。',
                //   parameter: 'test',
                //   service: '不支持退货'
                  
                // }
              ]
            },
            {
              id: "taocan",
              banner: '../../../image/bk/banner.jpg',
              cate: '冻龄白金',
              detail: [
                {
                  id: 'bk4',
                  thumb: "https://i.postimg.cc/0QWBh2k2/c4.png",
                  // thumb: "../../../image/bk/c4.png",
                  name: "小棕瓶",
                  price: 700,
                  stock: '有货',
                  detail: '这里是小棕瓶精华详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },
                {
                  id: 'bk5',
                  thumb: "https://i.postimg.cc/FKKqpLvn/c5.png",
                  name: "樱花精华水",
                  price: 550,
                  stock: '有货',
                  detail: '这里是樱花精华水详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },
                {
                  id: 'bk6',
                  thumb: "https://i.postimg.cc/Kjtsj774/c6.png",
                  name: "美白精华",
                  price: 600,
                  stock: '有货',
                  detail: '这里是美白精华详情。',
                  parameter: 'test',
                  service: '不支持退货'
                }
              ]
            },
            {
              id: "zaocan",
              banner: '../../../image/bk/banner.jpg',
              cate: '肌肤需求',
              detail: [
                {
                  id: 'bk7',
                  thumb: "../../../image/bk/c7.png",
                  name: "第七代小棕瓶",
                  price: 700,
                  stock: '有货',
                  detail: '这里是第七代小棕瓶详情。',
                  parameter: 'test',
                  service: '不支持退货'
                  
                },
                {
                  id: 'bk8',
                  thumb: "https://i.postimg.cc/nrf0yj8x/c8.png",
                  name: "高能小棕瓶",
                  price: 850,
                  stock: '有货',
                  detail: '这里是高能小棕瓶详情。',
                  parameter: 'test',
                  service: '不支持退货'
                  
                },
                {
                  id: 'bk9',
                  thumb: "https://i.postimg.cc/QMBmVkhs/c9.png",
                  name: "全新淡斑精华",
                  price: 560,
                  stock: '有货',
                  detail: '这里是全新[打斑弹]精华详情。',
                  parameter: 'test',
                  service: '不支持退货'
                  
                },
              ]
            },
            {
              id: "xiaoshi",
              banner: '../../../image/bk/banner.jpg',
              cate: '彩妆分类',
              detail: [
                {
                  id: 'bk11',
                  thumb: "../../../image/bk/c11.png",
                  name: "倾慕哑光唇膏",
                  price: 280,
                  stock: '有货',
                  detail: '这里是倾慕哑光唇膏详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },
                
              ]
            },
            {
              id: "tiandian",
              banner: '../../../image/bk/banner.jpg',
              cate: '专研系列',
              detail: [
                {
                  id: 'bk12',
                  thumb: "../../../image/bk/c12.png",
                  name: "纤雕精华",
                  price: 680,
                  stock: '有货',
                  detail: '这里是纤雕精华详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },

              ]
            },
            {
              id: "yinliao",
              banner: '../../../image/bk/banner.jpg',
              cate: '护肤分类',
              detail: [
                {
                  id: 'bk13',
                  thumb: "https://i.postimg.cc/d3KpFSML/c13.png",
                  name: "红石榴倍润水",
                  price: 440,
                  stock: '有货',
                  detail: '这里是红石榴倍润水详情。',
                  parameter: 'test',
                  service: '不支持退货'
                },

              ]
            },
          ]
        })
      } else if (options.d === 'ycyk') {
        console.log('MAC旗舰店')
        this.setData({
          category: [
            { name: '经典唇妆', id: 'guowei' },
            { name: '王牌底妆', id: 'shucai' },
            { name: '实力控妆', id: 'chaohuo' },
            { name: '晴彩眼妆', id: 'danfan' }
          ],
          detail: [
          {
            id: "guowei",
            banner: '../../../image/bk/banner2.jpg',
            cate: '经典唇妆',
            detail: [
              {
                id: 'bk14',
                thumb: "../../../image/bk/c14.png",
                name: "尤雾弹",
                price: 170,
                stock: '有货',
                detail: '这里是MAC尤雾弹详情。',
                parameter: 'test',
                service: '不支持退货'
              },
            ]
          }
          ]
        })
      } else if (options.d === 'dj') {
        this.setData({
          category: [
            { name: '系列家族', id: 'dianxin' },
            { name: '量肤定制', id: 'zoulei' },
            { name: '人气香氛', id: 'duntang' },
            { name: '彩妆分类', id: 'chaodian' },
          ]
        })
        console.log('兰蔻')
      } else if (options.d === 'xyx') {
        console.log('香奈儿')
        this.setData({
          category: [
            { name: '奢华精粹', id: 'xianyuxian' },
            { name: '彩妆时尚', id: 'binglei' },
            { name: '香水造诣', id: 'yingpin' },
          ]
        })
      } else if (options.d === 'hdl') {
        console.log('YSL')
        this.setData({
          category: [
            { name: '个性唇妆', id: 'guodi' },
            { name: '精致底妆', id: 'teshecaipin' },
            { name: '人气香氛', id: 'haixian' },
            { name: '高定香水', id: 'doumianzhipin' },
            { name: '高能护肤', id: 'yecailei' },
          ]
        })
      } else {
        this.setData({
          category: [
            { name: '个性唇妆', id: 'guodi' },
            { name: '精致底妆', id: 'teshecaipin' },
            { name: '人气香氛', id: 'haixian' },
            { name: '高定香水', id: 'doumianzhipin' },
            { name: '高能护肤', id: 'yecailei' },
          ]
        })
      }
      // 页面初始化 options为页面跳转所带来的参数
    },
    onReady(){
        // var self = this;
        // wx.request({
        //     url:'http://www.gdfengshuo.com/api/wx/cate-detail.txt',
        //     success(res){
        //         self.setData({
        //             detail : res.data
        //         })
        //     }
        // });
        
    },
    switchTab(e){
      const self = this;
      this.setData({
        isScroll: true
      })
      setTimeout(function(){
        self.setData({
          toView: e.target.dataset.id,
          curIndex: e.target.dataset.index
        })
      },0)
      setTimeout(function () {
        self.setData({
          isScroll: false
        })
      },1)
        
    },
    redTo: function(e) {
      // 获取物品详细信息
      let shopdetail = e.currentTarget.dataset.value 
      // 将json对象转化为string 以url get的方式传送数据
      shopdetail = JSON.stringify(shopdetail)
      // 页面跳转
      wx.navigateTo({
        url: '../details/details?d=' + shopdetail
      })
    }
    
})